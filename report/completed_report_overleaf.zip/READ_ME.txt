Open project_report.tex as the main file in Overleaf. All required figures
are included in this folder. part4_section.tex is a separate copy of Srikar's
section for pasting into another report; do not insert it again into the
combined file.

The latest pasted source was used. Other members' prose and numbers are
unchanged. Only three syntax repairs were made: amsmath and booktabs packages,
and the missing begin{center} before the Part 2 heading. Current figures are
copied from results/, not from older report copies.

Srikar's completed section includes topology, SPICE reference, lookup and
current correction, validation evidence, five-method results, leakage medians,
both figures, worked calculation, worst-case and temperature analysis,
comparison with gate-level accuracy, limitations and artifact inventory.
The reported mean accuracy is 98.60%, below the 99% objective.

TEAM CORRECTIONS (not applied to their text):
1. Part 3: refresh the overall table, all gate rows, variants and related
   discussion from results/part3/. Current overall median/p95/mean errors are
   1.33% / 4.71% / 1.81%, not 1.30% / 4.78% / 1.76%. Also revisit the wrong-sign
   example and training-region counts. The updated plot is already included.
2. Setup: distinguish the simulator versions; the saved Part 4 reference uses
   ngspice-47. Clarify eight data bits plus one parity bit (nine inputs total).
3. Part 1: verify the threshold-voltage trend text and quoted ratios against
   regenerated sweeps. validation_summary.txt says PMOS OFF current increases
   with signed vth0, whereas the prose says it decreases. Explain whether
   signed threshold or threshold magnitude is meant. Describe the first
   sampling paragraph as the uniform half, since the other half is targeted.
4. Part 3: the SPICE-reference paragraph says 'The lines below' but no netlist
   excerpt follows; include the intended excerpt or remove that sentence.
Part 2's model choices and headline gate/circuit numbers already match the
latest results; no replacement is needed for those statements.

VALIDATION SCOPE:
Other-member preservation, environment balance, labels/references, figure
availability and absence of Part 4 placeholders were checked. Current result
metrics had been independently recomputed from committed predictions.
The historical .op/DC cross-check is explicitly distinguished from current
reference validation; it was not rerun for this report.
No LaTeX compiler is available locally, so PDF compilation and visual page
layout must be checked in Overleaf. No PDF is claimed as verified.
